# Makefile #
I included a makefile for you convenience.
Simply running make should build the program.

